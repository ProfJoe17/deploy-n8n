#!/bin/bash
# =============================================================================
#  push-to-github.sh
#  Run this script once on your local machine to create the GitHub repo
#  and push all files. Requires: git, curl
# =============================================================================
set -euo pipefail

GITHUB_TOKEN="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"
GITHUB_USER="ProfJoe17"
REPO_NAME="deploy-n8n"
REPO_DESC="A powerful Bash deployment manager for n8n + external Python/JS task runners via Docker Compose"

echo "─── Step 1: Creating GitHub repository '${REPO_NAME}'..."
RESPONSE=$(curl -s -w "\n%{http_code}" \
  -X POST \
  -H "Authorization: Bearer ${GITHUB_TOKEN}" \
  -H "Accept: application/vnd.github+json" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  https://api.github.com/user/repos \
  -d "{
    \"name\": \"${REPO_NAME}\",
    \"description\": \"${REPO_DESC}\",
    \"private\": false,
    \"has_issues\": true,
    \"has_projects\": false,
    \"has_wiki\": false,
    \"auto_init\": false
  }")

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | head -n-1)

if [ "$HTTP_CODE" = "201" ]; then
  echo "    ✔  Repository created: https://github.com/${GITHUB_USER}/${REPO_NAME}"
elif [ "$HTTP_CODE" = "422" ]; then
  echo "    ℹ  Repository already exists — proceeding with push."
else
  echo "    ✖  Unexpected response (HTTP ${HTTP_CODE}):"
  echo "$BODY"
  exit 1
fi

echo ""
echo "─── Step 2: Initialising local git repo and pushing files..."

# Move to the directory where this script lives (i.e. the repo files)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

git init -b main
git config user.email "deploy-n8n@github.com"
git config user.name "${GITHUB_USER}"
git remote remove origin 2>/dev/null || true
git remote add origin "https://${GITHUB_USER}:${GITHUB_TOKEN}@github.com/${GITHUB_USER}/${REPO_NAME}.git"
git add .
git commit -m "feat: initial release — deploy-n8n v1.0.0

- Single-file Bash deployment manager for n8n
- Manages n8n + external Python/JS task runners via Docker Compose
- Interactive version picker (update) and one-click upgrade
- Automated backup/restore, health checks, concurrency locking
- Ollama/local-AI ready via host.docker.internal
- CI/CD friendly with -f force flag
- Comprehensive README"

git push -u origin main --force

echo ""
echo "─────────────────────────────────────────────────────────"
echo "  ✔  All done!"
echo "  Repo: https://github.com/${GITHUB_USER}/${REPO_NAME}"
echo "─────────────────────────────────────────────────────────"
